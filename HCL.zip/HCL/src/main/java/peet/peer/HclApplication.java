package peet.peer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HclApplication {

	public static void main(String[] args) {
		SpringApplication.run(HclApplication.class, args);
	}

}
