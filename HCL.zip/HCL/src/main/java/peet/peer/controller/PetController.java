package peet.peer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import peet.peer.dao.*;

import peet.peer.entity.*;

import java.util.List;

@RestController
public class PetController {

	@Autowired
	private PetDao dao;

	@PostMapping("/savePet")
	public Pet savePet(@RequestBody Pet pet) {

		return dao.savePet(pet);
	}

	@GetMapping("/fetchPet")
	public List<Pet> fetchPet(Pet pet) {

		return (List<Pet>) dao.fetchPet(pet);

	}

}
