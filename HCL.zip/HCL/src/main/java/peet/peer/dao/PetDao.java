package peet.peer.dao;

import peet.peer.entity.*;

public interface PetDao {
	
	public Pet savePet(Pet pet);
	
	public java.util.List<Pet>fetchPet(Pet fetchPet);

}
