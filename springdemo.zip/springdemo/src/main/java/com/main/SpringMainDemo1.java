package com.main;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.model.Student;

public class SpringMainDemo1 {

public static void main(String[] args) {
	ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springconfig.xml");
	Student student = (Student) applicationContext.getBean("student");
	System.out.println("Rool : " + student.getStudNo());
	System.out.println("Name : " + student.getStudentName());
	System.out.println("age : " + student.getage());
	System.out.println("the end");
}
}
