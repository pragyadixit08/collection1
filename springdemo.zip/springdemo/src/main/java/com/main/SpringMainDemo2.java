package com.main;
import java.util.Set;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.model.Student;
import com.model.Teacher;

public class SpringMainDemo2 {

public static void main(String[] args) {
	ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springconfig.xml");
	Teacher teacher = (Teacher) applicationContext.getBean("teacher");
	System.out.println("Id : " + teacher.getTeachId());
	System.out.println("Name : " + teacher.getTeachName());
	System.out.println("Qualification : " + teacher.getQualification());
	
	
	System.out.println("the end");
}
}
