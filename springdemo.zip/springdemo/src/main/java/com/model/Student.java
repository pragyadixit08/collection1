package com.model;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
public  class Student implements InitializingBean,DisposableBean{

	private int studNo;
	private String studentName;
	private int age;
	public Student() {

		super();
		System.out.println("Student Constructer");

		
	}
	
	public Student(int studNo, String studentName, int age) {
		super();
		this.studNo = studNo;
		this.studentName = studentName;
		this.age = age;
	}

	public int getStudNo() {
		return studNo;
	}

	public void setStudNo(int studNo) {
		this.studNo = studNo;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getage() {
		return age;
	}

	public void setage(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student [studNo=" + studNo + ", studentName=" + studentName + ", age=" + age + "]";
	}

		
	
	public void afterPropertiesSet() throws Exception {
		System.out.println("InitializingBean() ");
	}

	public void destroy() throws Exception {
		System.out.println("DisposableBean - destroy == close");
		
	}
		
	}

	
