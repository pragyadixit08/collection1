package com.model;
import java.util.Set;
public class Teacher {
	private int teachId;
	private String teachName;
	private int qualification;
	public Set<Student> student; //1 Teacher has many student 
		
	
	

	public Teacher(int teachId, String teachName, int qualification, Set<Student> student) {
		super();
		this.teachId = teachId;
		this.teachName = teachName;
		this.qualification = qualification;
		this.student = student;
	}


	public Teacher() {
		super();
	}


	public int getTeachId() {
		return teachId;
	}


	public void setTeachId(int teachId) {
		this.teachId = teachId;
	}


	public String getTeachName() {
		return teachName;
	}


	public void setTeachName(String teachName) {
		this.teachName = teachName;
	}


	public int getQualification() {
		return qualification;
	}


	public void setQualification(int qualification) {
		this.qualification = qualification;
	}


	public Set<Student> getStudent() {
		return student;
	}


	public void setStudent(Set<Student> student) {
		this.student = student;
	}
	

}
